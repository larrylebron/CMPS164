#include "Camera.h"


Camera::Camera(void)
{
}


Camera::~Camera(void)
{
}
